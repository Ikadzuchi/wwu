// charCount.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include <string.h>

void unicode2utf8(unsigned short input, char* output);
void main(int argc, char* argv[])
{
	FILE *file;
	char path[260];
	char* path1;
	int i;
	int bin[0x10000];
	for(i=0;i<0x10000;i++){
		bin[i]=0;
	}
	char tempc;
	char temps[5];
	unsigned short *temp;
	temp=(unsigned short*)malloc(2);
	if(argc>=2){
		strncpy(path,argv[1],260);
		path[259]='\0';
		file=fopen(argv[1],"rb");
		while(fread(temp,2,1,file)==1){
			bin[*temp]++;
		}
		fclose(file);
	}

	path1=strrchr(path,'\\')+1;
	strcpy(path1,"out.txt");

	file=fopen(path,"wb");
	unicode2utf8(0xFEFF,temps);
	fprintf(file,temps);
	for(i=0;i<0x10000;i++){
		unicode2utf8(i,temps);
		fprintf(file,temps);
		fprintf(file,"\t%X\t%d\r\n",i,bin[i]);
	}
	fclose(file);
	printf("done.");
}
void unicode2utf8(unsigned short input, char* output){
	if(input <= 0x7F){
		output[0]=(char)input;
		output[1]='\0';
	}
	else if(input <= 0x7FF){
		output[0]=(( input&0x7C0 )>>6)|0xC0;
		output[1]=(input&0x3F)|0x80;
		output[2]='\0';
	}
	else if(input <= 0xFFFF){
		output[0]=(( input&0xF000 )>>12)|0xE0;
		output[1]=(( input&0xFC0 )>>6)|0x80;
		output[2]=(input&0x3F)|0x80;
		output[3]='\0';
	}
	else if(input <= 0x1FFFFF){
		output[0]=(( input&0x1C0000 )>>12)|0xF0;
		output[1]=(( input&0x3F000 )>>6)|0x80;
		output[2]=(( input&0xFC0 )>>6)|0x80;
		output[3]=(input&0x3F)|0x80;
		output[4]='\0';
	}
	else{
		output[0]='?';
		output[1]='\0';
	}
}
